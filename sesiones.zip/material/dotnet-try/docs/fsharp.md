# dotnet try

This is an interactive Try .NET editor.

``` fsharp --source-file ./samples/FSharpConsole/Program.fs --project ./samples/FSharpConsole/FSharpConsole.fsproj  --region some_region
printfn "hello from F#"
```
