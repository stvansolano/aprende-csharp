# dotnet try

This is an interactive Try .NET editor.

```csharp --source-file ./samples/BasicConsole/Program.cs --project ./samples/BasicConsole/BasicConsole.csproj  --region wat --session "say meow..."
```

This code in another file. They compile and execute together when you you click the run button.

```csharp --project ./samples/BasicConsole/BasicConsole.csproj --source-file ./samples/BasicConsole/Cat.cs --region WhatToSay --session "...or"
```




