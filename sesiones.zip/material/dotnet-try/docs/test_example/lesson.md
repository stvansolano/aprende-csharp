Make this test pass:

```csharp --source-file UnitTest1.cs --region test1 --session "Run my tests!"
```

Here's the body of the `GetValue` method:

```csharp --source-file ClassBeingTested.cs --region GetValue --session "Run my tests!"
```
