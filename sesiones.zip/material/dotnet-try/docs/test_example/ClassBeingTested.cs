// Copyright (c) .NET Foundation and contributors. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

namespace test_example
{

    public static class ClassBeingTested
    {
            #region GetValue
        public static int GetValue()
        {
                return 1;
        }
            #endregion
    }
}