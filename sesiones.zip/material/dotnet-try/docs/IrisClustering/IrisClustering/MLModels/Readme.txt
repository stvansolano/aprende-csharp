﻿This folder is empty until you run the training console app and create/train and save the models as .ZIP files.
Those model .ZIP files should appear in this folder.