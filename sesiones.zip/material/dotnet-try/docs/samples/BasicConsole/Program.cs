// Copyright (c) .NET Foundation and contributors. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

using System;

namespace BasicConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            #region wat
            Console.WriteLine(new Cat().Say());
            #endregion
        }
    }
}
