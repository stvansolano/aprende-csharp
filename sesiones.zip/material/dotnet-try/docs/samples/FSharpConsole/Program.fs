// Copyright (c) .NET Foundation and contributors. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

module FSharpConsole

[<EntryPoint>]
let main(args: string[]) =
    //#region some_region
    printfn "hello from F#"
    //#endregion
    0
