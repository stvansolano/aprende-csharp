export const panel: string;
export const httpRequest: string;
export const runningContainer: string;
