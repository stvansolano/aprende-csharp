// Copyright (c) .NET Foundation and contributors. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

import { AnyAction } from "redux";

export interface CookieUpdater<TState> {
    (oldState: TState, newState: TState): AnyAction;
}
