export const embeddable: string;
export const editor: string;
